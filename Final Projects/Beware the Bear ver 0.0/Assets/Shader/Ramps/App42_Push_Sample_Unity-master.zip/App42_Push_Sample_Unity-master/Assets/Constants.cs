using UnityEngine;
using System.Collections;

public class Constants {

	public string apiKey ="<YOUR API KEY>";
	public string secretKey="<YOUR SECRET KEY>";
	public string projectNo="<YOUR PROJECT NO>";
	public string userId="<YOUR USER ID>";
 // public string callBackMethod="<CALLBACK METHOD>";
	public string callBackMethod="Success";
 //	public string gameObjectName="<GAME OBJECT NAME>";
	public string gameObjectName="app42Msg";
}
